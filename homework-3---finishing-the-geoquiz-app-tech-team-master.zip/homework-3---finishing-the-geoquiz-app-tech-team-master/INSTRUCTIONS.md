
# CPSC 411A - Homework 3 - Finishing the GeoQuiz App

For this homework, you will complete the *GeoQuiz App* as described in the book, all the way to the end of Chapter 6 (excluding extra "challenges"). Read the following steps carefully and assume any generic steps will be assumed in all future assignments.

Do the assignment exactly as described in the textbook. Do not add extra upgrades or creative deviations. Submissions that deviate in any way from the exact description supplied by the textbook will most likely be subject to deductions. If you wish to get creative or challenge yourself further than what is assigned, make a new private repo and do so there.
