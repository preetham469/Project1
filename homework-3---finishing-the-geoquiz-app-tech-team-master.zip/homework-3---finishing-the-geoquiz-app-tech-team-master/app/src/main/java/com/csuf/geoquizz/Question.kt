package com.csuf.geoquizz

data class Question(val question:String,val answer:Boolean )