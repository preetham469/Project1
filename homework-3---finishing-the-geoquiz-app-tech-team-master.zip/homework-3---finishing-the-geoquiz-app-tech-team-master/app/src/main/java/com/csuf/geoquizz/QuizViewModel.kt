package com.csuf.geoquizz

import android.util.Log
import androidx.lifecycle.ViewModel

private const val TAG="QuizViewModel"
class QuizViewModel : ViewModel() {

    var currentIndex = 0
    var isCheater = false

    private var questionBank = listOf(
        Question("New Delhi is capital of India",true),
        Question("Sacramento is the capital of California state",true),
        Question("There are 30 states in the United States of America",false),
        Question("Nile is longest river in the world",true) ,
        Question("Asia is the largest continent in the world",true),
        Question("There are 8 continent in the world",false),
        Question("China has largest population in the world",true)
    )

    init {
        Log.d(TAG,"ViewModel instance created")
    }

    override fun onCleared() {
        super.onCleared()
        Log.d(TAG,"ViewModel instance about to be destroyed")
    }

    val currentQuestionAnswer: Boolean
        get() = questionBank[currentIndex].answer

    val currentQuestionText: String
        get() = questionBank[currentIndex].question

    fun moveToNext(){
        currentIndex = (currentIndex + 1) % questionBank.size
    }

}